这里要推荐一个博主的文章，里面对粒子滤波的理论阐述得清晰易懂，跟着链接学习。

Particle Filter Tutorial 粒子滤波：从推导到应用

[https://blog.csdn.net/heyijia0327/article/details/40899819](https://blog.csdn.net/heyijia0327/article/details/40899819)

[http://blog.csdn.net/heyijia0327/article/details/40929097](http://blog.csdn.net/heyijia0327/article/details/40929097)

[http://blog.csdn.net/heyijia0327/article/details/41122125](http://blog.csdn.net/heyijia0327/article/details/41122125)

[http://blog.csdn.net/heyijia0327/article/details/41142679](http://blog.csdn.net/heyijia0327/article/details/41142679)
